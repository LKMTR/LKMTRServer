// MTR模组M-Train资趣台 v1.7 —— 3000×500 设备 / 2400×400 虚拟（统一 1.25 缩放，无拉伸）
// 2026年-当前 仙芳佳全域通达铁路、乐文彩雨 版权所有  MIT
// 作者b站：https://space.bilibili.com/104383166
importPackage(java.awt);
importPackage(java.awt.geom);
importPackage(java.lang.math);

// 设计在“虚拟”坐标里画（与 v1.6 完全相同的数值），由 DrawInfoPanel 统一 ×SCALE 投到设备像素。
// 2400×1.25 = 3000，400×1.25 = 500 → 竖向比例与旧版逐像素一致，字形等比放大、不变形。
const SCALE = 1.25;
const DEVICE_W = 3000, DEVICE_H = 500;     // 每面墙的真实纹理尺寸（=texArea 的 w/h）
const WIDTH1 = 2400, HEIGHT1 = 400;        // 虚拟画板（绘制代码用这套数）
const LINEY = HEIGHT1 / 2;                 // 200 虚拟 → 250 设备 = 竖向正中

const SERIF = Resources.getSystemFont("Noto Serif"),
      SANS  = Resources.getSystemFont("Noto Sans");
const WHITE = Color.decode("#ffffff"),
      DARK_GREY = Color.decode("#404040"),
      BLACK = Color.decode("#000000"),
      ORANGE = Color.decode("#FF8000"),
      GREEN = Color.decode("#00C000"),
      LIGHT_GREY = Color.decode("#A0A0A0"),
      YELLOW = Color.decode("#FFFF00");

// 以下常量与 v1.6 逐字相同（在虚拟空间里），无需改动 —— 缩放由 SCALE 统一完成。
const MARGIN = 160;
const LEGENDMARGIN = 80;
const WIDTH = 30;
const RADIUS = 40;
const BORDER = 10;
const DOORCLOSESEC = 3;
const ARRIVALRADIUS = 120;
const ARRIVALBORDER = 30;
const ARRIVALYELLOWPARTHEIGHT = 110;
const INTERCHANGESPACING = 10;
const CONNECTINGINTERCHANGESPACING = 80;

function CentreText(g, text, x, y, xLimit) {
    let xNew = 0, transform0, widthNow, widthNew, yNew;
    widthNow = g.getFontMetrics().stringWidth(text);
    if (xLimit > 0 && widthNow > xLimit) { transform0 = g.getTransform(); g.scale(xLimit / widthNow, 1); x /= xLimit / widthNow; }
    widthNew = g.getFontMetrics().stringWidth(text);
    xNew = x - widthNew / 2; yNew = y;
    g.drawString(text, xNew, yNew);
    if (xLimit > 0 && widthNow > xLimit) { g.scale(xLimit / widthNow, 1); g.setTransform(transform0); }
}
function RightText(g, text, x, y, xLimit) {
    let xNew = 0, transform0, widthNow, widthNew, yNew;
    widthNow = g.getFontMetrics().stringWidth(text);
    if (xLimit > 0 && widthNow > xLimit) { transform0 = g.getTransform(); g.scale(xLimit / widthNow, 1); x /= xLimit / widthNow; }
    widthNew = g.getFontMetrics().stringWidth(text);
    xNew = x - widthNew; yNew = y;
    g.drawString(text, xNew, yNew);
    if (xLimit > 0 && widthNow > xLimit) { g.scale(xLimit / widthNow, 1); g.setTransform(transform0); }
}
function LeftText(g, text, x, y, xLimit) {
    let xNew = 0, transform0, widthNow, widthNew, yNew;
    widthNow = g.getFontMetrics().stringWidth(text);
    if (xLimit > 0 && widthNow > xLimit) { transform0 = g.getTransform(); g.scale(xLimit / widthNow, 1); x /= xLimit / widthNow; }
    widthNew = g.getFontMetrics().stringWidth(text);
    xNew = x; yNew = y;
    g.drawString(text, xNew, yNew);
    if (xLimit > 0 && widthNow > xLimit) { g.scale(xLimit / widthNow, 1); g.setTransform(transform0); }
}
function CentreTextXY(g, text, x, y, xLimit) {
    let xNew = 0, transform0, widthNow, widthNew, yNew, heightNew;
    widthNow = g.getFontMetrics().stringWidth(text);
    if (xLimit > 0 && widthNow > xLimit) { transform0 = g.getTransform(); g.scale(xLimit / widthNow, 1); x /= xLimit / widthNow; }
    widthNew = g.getFontMetrics().stringWidth(text);
    heightNew = g.getFontMetrics().getHeight();
    xNew = x - widthNew / 2; yNew = y + heightNew / 4;
    g.drawString(text, xNew, yNew);
    if (xLimit > 0 && widthNow > xLimit) { g.scale(xLimit / widthNow, 1); g.setTransform(transform0); }
}
function RightTextXY(g, text, x, y, xLimit) {
    let xNew = 0, transform0, widthNow, widthNew, yNew, heightNew;
    widthNow = g.getFontMetrics().stringWidth(text);
    if (xLimit > 0 && widthNow > xLimit) { transform0 = g.getTransform(); g.scale(xLimit / widthNow, 1); x /= xLimit / widthNow; }
    widthNew = g.getFontMetrics().stringWidth(text);
    heightNew = g.getFontMetrics().getHeight();
    xNew = x - widthNew; yNew = y + heightNew / 4;
    g.drawString(text, xNew, yNew);
    if (xLimit > 0 && widthNow > xLimit) { g.scale(xLimit / widthNow, 1); g.setTransform(transform0); }
}
function LeftTextXY(g, text, x, y, xLimit) {
    let xNew = 0, transform0, widthNow, widthNew, yNew, heightNew;
    widthNow = g.getFontMetrics().stringWidth(text);
    if (xLimit > 0 && widthNow > xLimit) { transform0 = g.getTransform(); g.scale(xLimit / widthNow, 1); x /= xLimit / widthNow; }
    widthNew = g.getFontMetrics().stringWidth(text);
    heightNew = g.getFontMetrics().getHeight();
    xNew = x; yNew = y + heightNew / 4;
    g.drawString(text, xNew, yNew);
    if (xLimit > 0 && widthNow > xLimit) { g.scale(xLimit / widthNow, 1); g.setTransform(transform0); }
}