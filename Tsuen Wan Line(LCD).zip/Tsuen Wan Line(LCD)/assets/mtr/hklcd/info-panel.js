// MTR模组M-Train资趣台 v1.7 —— 3000×500（虚拟 2400×400 + 统一 1.25 缩放）
// 2026年-当前 仙芳佳全域通达铁路、乐文彩雨 版权所有  MIT
// 作者b站：https://space.bilibili.com/104383166
// 绘制代码与 v1.6 完全一致（虚拟坐标）；仅 DrawInfoPanel 增加“设备裁剪 + 统一缩放”，
// 左墙箭头改为“虚拟空间水平翻转”。双墙 transform/clip 修复保留。
importPackage(java.awt);
importPackage(java.awt.geom);
importPackage(java.lang.math);

const ARROW = Resources.readBufferedImage(Resources.idRelative("arrow.png"));
const RATIO = ARROW.getWidth(null) / ARROW.getHeight(null);
// mind-the-gap 图标：受保护加载，缺图为 null，绘制时跳过
let MTGL = null, MTGR = null;
try { MTGL = Resources.readBufferedImage(Resources.idRelative("mind_the_gap_l.png")); } catch (e) { MTGL = null; }
try { MTGR = Resources.readBufferedImage(Resources.idRelative("mind_the_gap_r.png")); } catch (e) { MTGR = null; }

const DOTTED = new BasicStroke(BORDER / 2, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10, [4, 2], 0);

// —— 布局常量（虚拟空间，与 v1.6 相同）——
const OUTER = 70;
const GAP = 24;
const EDGE = 6;
const MINZOOM = 0.35;
const CN_MARGIN = 160;
const OFFR = 51, OFFL = 30, OFFN = 15, HALF = RADIUS / 2;

// 已过站的换乘是否计入布局/绘制：
//   false（默认，符合“已过站只画灰点+灰名”的设计）→ 布局不为已过站换乘预留空间，已过站也不画换乘。
//       代价：全线路图在每次越过“换乘站”时会向左跳一下（该站保留区突然变小）。
//   true → 已过站也画换乘（彩色色块 + 灰胶囊），布局也预留空间 → 整图过站不跳，但已过区会出现彩色换乘色块。
const LAYOUT_COUNTS_PASSED_IC = false;

// —— Java 集合 / JS 数组 兼容 ——
function jlen(x) {
    if (x == null || x == undefined) { return 0; }
    if (typeof x.length == "number") { return x.length; }
    if (typeof x.size == "function") { return x.size(); }
    return 0;
}
function jget(x, i) {
    if (x == null || x == undefined) { return undefined; }
    if (typeof x.get == "function") { return x.get(i); }
    return x[i];
}
function mapKeys(m) {
    let keys = [];
    if (m == null || m == undefined) { return keys; }
    if (typeof m.keySet == "function") {
        let it = m.keySet().iterator();
        while (it.hasNext()) { keys.push(it.next()); }
    } else { for (let k in m) { if (m.hasOwnProperty(k)) { keys.push(k); } } }
    return keys;
}
function jmapget(m, k) {
    if (m == null || m == undefined) { return undefined; }
    if (typeof m.get == "function") { return m.get(k); }
    return m[k];
}

// —— 文本宽度 ——
function tw(g, text, size, font) {
    if (text == null || text == undefined || text == "") { return 0; }
    try { g.setFont(font.deriveFont(0, size)); return g.getFontMetrics().stringWidth(text); }
    catch (e) { return 0; }
}
function lineNameW(g, ic) {
    return Math.max(tw(g, TextUtil.getCjkParts(ic.name), 20, SERIF),
                    tw(g, TextUtil.getNonCjkParts(ic.name), 10, SANS));
}
function conNameW(g, stn) {
    return Math.max(tw(g, TextUtil.getCjkParts(stn), 20, SERIF),
                    tw(g, TextUtil.getNonCjkParts(stn), 10, SANS));
}
function stationNameW(g, nm) {
    return Math.max(tw(g, TextUtil.getCjkParts(nm), 30, SERIF),
                    tw(g, TextUtil.getNonCjkParts(nm), 15, SANS));
}

function measure(g, rp, countIc) {
    if (countIc == false) {
        // 已过站不画换乘 → 布局也不预留：只保留“圆点 + 居中站名”的宽度
        return { nameW: stationNameW(g, rp.station.name), rightLabelNat: 0, leftNameNat: 0,
                 singleNat: 0, leftShift: false, icsSize: 0, hasConics: false };
    }
    let ics = rp.routeInterchanges, conics = rp.connectingInterchanges;
    let icsSize = jlen(ics), conKeys = mapKeys(conics), hasConics = conKeys.length > 0;
    let rightLabelNat = 0, leftNameNat = 0, singleNat = 0;
    if (icsSize == 1) { singleNat = lineNameW(g, jget(ics, 0)); }
    if (icsSize > 1) { for (let c = 0; c < icsSize; c++) { rightLabelNat = Math.max(rightLabelNat, lineNameW(g, jget(ics, c))); } }
    if (hasConics) {
        for (let ki = 0; ki < conKeys.length; ki++) {
            let stn = conKeys[ki];
            leftNameNat = Math.max(leftNameNat, conNameW(g, stn));
            let cl = jmapget(conics, stn);
            for (let c = 0; c < jlen(cl); c++) { rightLabelNat = Math.max(rightLabelNat, lineNameW(g, jget(cl, c))); }
        }
    }
    return {
        nameW: stationNameW(g, rp.station.name),
        rightLabelNat: rightLabelNat, leftNameNat: leftNameNat, singleNat: singleNat,
        leftShift: (icsSize > 0 && hasConics),
        icsSize: icsSize, hasConics: hasConics
    };
}
function keepouts(m) {
    let L = HALF, R = HALF;
    if (m.leftNameNat > 0)   { L = Math.max(L, OFFL + m.leftNameNat); }
    if (m.rightLabelNat > 0) { R = Math.max(R, OFFR + m.rightLabelNat); }
    if (m.singleNat > 0)     { L = Math.max(L, m.singleNat / 2); R = Math.max(R, m.singleNat / 2); }
    if (m.leftShift)         { R = Math.max(R, OFFN + m.nameW); }
    else                     { let h = m.nameW / 2; L = Math.max(L, h); R = Math.max(R, h); }
    return { L: L, R: R };
}
function limsOf(m) {
    return {
        rightLabel: m.rightLabelNat + 1, leftName: m.leftNameNat + 1,
        single: m.singleNat + 1, nameC: m.nameW + 1, nameL: m.nameW + 1
    };
}

function layoutWhole(g, routePlats, idxList, ns) {
    let n = idxList.length, M = [], K = [], lim = [], k;
    for (k = 0; k < n; k++) {
        let drawIc = LAYOUT_COUNTS_PASSED_IC || (idxList[k] >= ns);
        M[k] = measure(g, jget(routePlats, idxList[k]), drawIc);
        K[k] = keepouts(M[k]);
        lim[k] = limsOf(M[k]);
    }
    let X = [];
    if (n <= 1) {
        X[0] = WIDTH1 / 2;
        return { X: X, lim: lim, s: 1, transformed: false };
    }
    X[0] = K[0].L;
    for (k = 1; k < n; k++) { X[k] = X[k - 1] + K[k - 1].R + GAP + K[k].L; }
    let span = X[n - 1] + K[n - 1].R;
    let avail = WIDTH1 - 2 * OUTER;
    let s = (span > avail) ? (avail / span) : 1;
    if (s > 1) { s = 1; }
    if (s < MINZOOM) { s = MINZOOM; }
    if (s >= 1 - 1e-9) {
        let off = (WIDTH1 - span) / 2;
        for (k = 0; k < n; k++) { X[k] += off; }
        return { X: X, lim: lim, s: 1, transformed: false };
    }
    let tx = (WIDTH1 - s * span) / 2, ty = LINEY * (1 - s);
    return { X: X, lim: lim, s: s, span: span, tx: tx, ty: ty, transformed: true };
}

function layoutComing(g, routePlats, idxList, ns) {
    let n = idxList.length, M = [], K = [], base = [], k;
    for (k = 0; k < n; k++) { let drawIc = LAYOUT_COUNTS_PASSED_IC || (idxList[k] >= ns); M[k] = measure(g, jget(routePlats, idxList[k]), drawIc); K[k] = keepouts(M[k]); }
    for (k = 0; k < n; k++) { base[k] = (n > 1) ? (CN_MARGIN + k * (WIDTH1 - 2 * CN_MARGIN) / (n - 1)) : (WIDTH1 / 2); }
    let minGap = [];
    for (k = 1; k < n; k++) { minGap[k] = K[k - 1].R + K[k].L + GAP; }
    let eff = [];
    for (k = 0; k < n; k++) {
        let fl = K[k].L + EDGE, cp = WIDTH1 - EDGE - K[k].R, b = base[k];
        if (b < fl) { b = fl; }
        if (b > cp) { b = cp; }
        eff[k] = b;
    }
    let X = [];
    for (let it = 0; it < 4; it++) {
        X[0] = eff[0];
        for (k = 1; k < n; k++) { X[k] = Math.max(eff[k], X[k - 1] + minGap[k]); }
        X[n - 1] = Math.min(X[n - 1], WIDTH1 - EDGE - K[n - 1].R);
        for (k = n - 2; k >= 0; k--) { X[k] = Math.min(X[k], X[k + 1] - minGap[k + 1]); }
        if (X[0] < K[0].L + EDGE) { X[0] = K[0].L + EDGE; }
        for (k = 1; k < n; k++) { if (X[k] < X[k - 1] + minGap[k]) { X[k] = X[k - 1] + minGap[k]; } }
    }
    let leftEdge = X[0] - K[0].L, rightEdge = X[n - 1] + K[n - 1].R;
    let transformed = false, s = 1, tx = 0, ty = 0, span = rightEdge - leftEdge;
    if (leftEdge < EDGE || rightEdge > WIDTH1 - EDGE) {
        s = (WIDTH1 - 2 * OUTER) / span;
        if (s > 1) { s = 1; }
        if (s < MINZOOM) { s = MINZOOM; }
        tx = (WIDTH1 - s * span) / 2 - s * leftEdge; ty = LINEY * (1 - s);
        transformed = true;
    }
    let lim = [];
    for (k = 0; k < n; k++) { lim[k] = limsOf(M[k]); }
    return { X: X, lim: lim, s: s, transformed: transformed, tx: tx, ty: ty };
}

function drawBarWhole(g, X, idxList, ns, routeColor) {
    for (let p = 0; p < idxList.length - 1; p++) {
        g.setColor(idxList[p] < ns - 1 ? LIGHT_GREY : routeColor);
        let x0 = X[p], x1 = X[p + 1];
        g.fillRect(Math.min(x0, x1), LINEY - WIDTH / 2, Math.abs(x1 - x0), WIDTH);
    }
}
function drawBarComing(g, X, idxList, ns, routeColor, start, N) {
    let n = idxList.length;
    if (start != 0) { g.setColor(LIGHT_GREY); g.fillRect(0, LINEY - WIDTH / 2, X[0], WIDTH); }
    for (let p = 0; p < n - 1; p++) {
        g.setColor(idxList[p] < ns - 1 ? LIGHT_GREY : routeColor);
        let x0 = X[p], x1 = X[p + 1];
        g.fillRect(Math.min(x0, x1), LINEY - WIDTH / 2, Math.abs(x1 - x0), WIDTH);
    }
    if (start + n - 1 != N - 1) { g.setColor(routeColor); g.fillRect(X[n - 1], LINEY - WIDTH / 2, WIDTH1 - X[n - 1], WIDTH); }
}

function drawStation(g, pcx, Lm, rp, i, ns, borderColor, NEXTCOLOR) {
    let icsSize = 0, hasConics = false;
    if (i >= ns || LAYOUT_COUNTS_PASSED_IC) {
        let ics = rp.routeInterchanges, conics = rp.connectingInterchanges;
        icsSize = jlen(ics);
        let conKeys = mapKeys(conics);
        hasConics = conKeys.length > 0;
        if (icsSize == 0 && hasConics) {
            let cony = LINEY, coniccy = {};
            for (let ki = 0; ki < conKeys.length; ki++) {
                let stn = conKeys[ki], conList = jmapget(conics, stn), conListSize = jlen(conList);
                g.setStroke(DOTTED); g.setColor(BLACK);
                g.drawLine(pcx, cony, pcx, cony - CONNECTINGINTERCHANGESPACING);
                cony = cony - CONNECTINGINTERCHANGESPACING;
                coniccy[stn] = cony - (conListSize * WIDTH + (conListSize - 1) * INTERCHANGESPACING) / 2;
                for (let ci = 0; ci < conListSize; ci++) {
                    let ic = jget(conList, ci), iccol = new Color(ic.color);
                    let icZh = TextUtil.getCjkParts(ic.name), icEn = TextUtil.getNonCjkParts(ic.name);
                    let iw = WIDTH, ilx = pcx, icy = cony - WIDTH / 2;
                    g.setColor(iccol);
                    g.fillRect(ilx, icy - iw / 2, iw * 1.25, iw);
                    g.fillOval(ilx + iw * 1.25 / 2, icy - iw / 2, iw, iw);
                    g.setColor(BLACK);
                    g.setFont(SERIF.deriveFont(0, 20)); LeftTextXY(g, icZh, ilx + iw * 1.7, icy - 5, Lm.rightLabel);
                    g.setFont(SANS.deriveFont(0, 10));  LeftTextXY(g, icEn, ilx + iw * 1.7, icy + 10, Lm.rightLabel);
                    cony = cony - WIDTH - INTERCHANGESPACING;
                }
                cony = cony + WIDTH + INTERCHANGESPACING;
            }
            for (let ki = 0; ki < conKeys.length; ki++) {
                let stn = conKeys[ki], stnics = jmapget(conics, stn), kk = jlen(stnics), cy = coniccy[stn];
                let h = kk * WIDTH + (kk - 1) * INTERCHANGESPACING + (RADIUS - WIDTH), ty = cy - h / 2;
                g.setColor(borderColor); g.fillRoundRect(pcx - RADIUS / 2, ty, RADIUS, h, RADIUS, RADIUS);
                let nd = RADIUS - BORDER; g.setColor(WHITE); g.fillRoundRect(pcx - nd / 2, ty + BORDER / 2, nd, h - BORDER, nd, nd);
                let nextZh = TextUtil.getCjkParts(stn), nextEn = TextUtil.getNonCjkParts(stn);
                g.setColor(BLACK);
                g.setFont(SERIF.deriveFont(0, 20)); RightTextXY(g, nextZh, pcx - WIDTH, cy - 5, Lm.leftName);
                g.setFont(SANS.deriveFont(0, 10));  RightTextXY(g, nextEn, pcx - WIDTH, cy + 10, Lm.leftName);
            }
        } else if (icsSize == 1) {
            let iic = jget(ics, 0), iiccol = new Color(iic.color);
            let iicZh = TextUtil.getCjkParts(iic.name), iicEn = TextUtil.getNonCjkParts(iic.name);
            let iiw = WIDTH, iicx = pcx, iirty = LINEY - iiw * 1.25, iity = iirty - iiw / 2;
            g.setColor(iiccol);
            g.fillRect(iicx - iiw / 2, iirty, iiw, iiw);
            g.fillOval(iicx - iiw / 2, iity, iiw, iiw);
            g.setColor(BLACK);
            g.setFont(SERIF.deriveFont(0, 20)); CentreText(g, iicZh, iicx, iity - 20, Lm.single);
            g.setFont(SANS.deriveFont(0, 10));  CentreText(g, iicEn, iicx, iity - 5, Lm.single);
            if (hasConics) {
                let cony = LINEY, coniccy = {};
                for (let ki = 0; ki < conKeys.length; ki++) {
                    let stn = conKeys[ki], conList = jmapget(conics, stn), conListSize = jlen(conList);
                    g.setStroke(DOTTED); g.setColor(BLACK);
                    g.drawLine(pcx, cony, pcx, cony + CONNECTINGINTERCHANGESPACING);
                    cony = cony + CONNECTINGINTERCHANGESPACING;
                    coniccy[stn] = cony + (conListSize * WIDTH + (conListSize - 1) * INTERCHANGESPACING) / 2;
                    for (let ci = 0; ci < conListSize; ci++) {
                        let ic = jget(conList, ci), iccol = new Color(ic.color);
                        let icZh = TextUtil.getCjkParts(ic.name), icEn = TextUtil.getNonCjkParts(ic.name);
                        let iw = WIDTH, ilx = pcx, icy = cony + WIDTH / 2;
                        g.setColor(iccol);
                        g.fillRect(ilx, icy - iw / 2, iw * 1.25, iw);
                        g.fillOval(ilx + iw * 1.25 / 2, icy - iw / 2, iw, iw);
                        g.setColor(BLACK);
                        g.setFont(SERIF.deriveFont(0, 20)); LeftTextXY(g, icZh, ilx + iw * 1.7, icy - 5, Lm.rightLabel);
                        g.setFont(SANS.deriveFont(0, 10));  LeftTextXY(g, icEn, ilx + iw * 1.7, icy + 10, Lm.rightLabel);
                        cony = cony + WIDTH + INTERCHANGESPACING;
                    }
                    cony = cony - WIDTH - INTERCHANGESPACING;
                }
                for (let ki = 0; ki < conKeys.length; ki++) {
                    let stn = conKeys[ki], stnics = jmapget(conics, stn), kk = jlen(stnics), cy = coniccy[stn];
                    let h = kk * WIDTH + (kk - 1) * INTERCHANGESPACING + (RADIUS - WIDTH), ty = cy - h / 2;
                    g.setColor(borderColor); g.fillRoundRect(pcx - RADIUS / 2, ty, RADIUS, h, RADIUS, RADIUS);
                    let nd = RADIUS - BORDER; g.setColor(WHITE); g.fillRoundRect(pcx - nd / 2, ty + BORDER / 2, nd, h - BORDER, nd, nd);
                    let nextZh = TextUtil.getCjkParts(stn), nextEn = TextUtil.getNonCjkParts(stn);
                    g.setColor(BLACK);
                    g.setFont(SERIF.deriveFont(0, 20)); RightTextXY(g, nextZh, pcx - WIDTH, cy - 5, Lm.leftName);
                    g.setFont(SANS.deriveFont(0, 10));  RightTextXY(g, nextEn, pcx - WIDTH, cy + 10, Lm.leftName);
                }
            }
        } else if (icsSize > 1) {
            for (let j = 0; j < icsSize; j++) {
                let ic = jget(ics, j);
                if (ic != undefined) {
                    let iccol = new Color(ic.color);
                    let icZh = TextUtil.getCjkParts(ic.name), icEn = TextUtil.getNonCjkParts(ic.name);
                    let iw = WIDTH, ilx = pcx, icy = LINEY - ((j + 1) * WIDTH + (j + 1) * INTERCHANGESPACING);
                    g.setColor(iccol);
                    g.fillRect(ilx, icy - iw / 2, iw * 1.25, iw);
                    g.fillOval(ilx + iw * 1.25 / 2, icy - iw / 2, iw, iw);
                    g.setColor(BLACK);
                    g.setFont(SERIF.deriveFont(0, 20)); LeftTextXY(g, icZh, ilx + iw * 1.7, icy - 5, Lm.rightLabel);
                    g.setFont(SANS.deriveFont(0, 10));  LeftTextXY(g, icEn, ilx + iw * 1.7, icy + 10, Lm.rightLabel);
                }
            }
            if (hasConics) {
                let cony = LINEY, coniccy = {};
                for (let ki = 0; ki < conKeys.length; ki++) {
                    let stn = conKeys[ki], conList = jmapget(conics, stn), conListSize = jlen(conList);
                    g.setStroke(DOTTED); g.setColor(BLACK);
                    g.drawLine(pcx, cony, pcx, cony + CONNECTINGINTERCHANGESPACING);
                    cony = cony + CONNECTINGINTERCHANGESPACING;
                    coniccy[stn] = cony + (conListSize * WIDTH + (conListSize - 1) * INTERCHANGESPACING) / 2;
                    for (let ci = 0; ci < conListSize; ci++) {
                        let ic = jget(conList, ci), iccol = new Color(ic.color);
                        let icZh = TextUtil.getCjkParts(ic.name), icEn = TextUtil.getNonCjkParts(ic.name);
                        let iw = WIDTH, ilx = pcx, icy = cony + WIDTH / 2;
                        g.setColor(iccol);
                        g.fillRect(ilx, icy - iw / 2, iw * 1.25, iw);
                        g.fillOval(ilx + iw * 1.25 / 2, icy - iw / 2, iw, iw);
                        g.setColor(BLACK);
                        g.setFont(SERIF.deriveFont(0, 20)); LeftTextXY(g, icZh, ilx + iw * 1.7, icy - 5, Lm.rightLabel);
                        g.setFont(SANS.deriveFont(0, 10));  LeftTextXY(g, icEn, ilx + iw * 1.7, icy + 10, Lm.rightLabel);
                        cony = cony + WIDTH + INTERCHANGESPACING;
                    }
                    cony = cony - WIDTH - INTERCHANGESPACING;
                }
                for (let ki = 0; ki < conKeys.length; ki++) {
                    let stn = conKeys[ki], stnics = jmapget(conics, stn), kk = jlen(stnics), cy = coniccy[stn];
                    let h = kk * WIDTH + (kk - 1) * INTERCHANGESPACING + (RADIUS - WIDTH), ty = cy - h / 2;
                    g.setColor(borderColor); g.fillRoundRect(pcx - RADIUS / 2, ty, RADIUS, h, RADIUS, RADIUS);
                    let nd = RADIUS - BORDER; g.setColor(WHITE); g.fillRoundRect(pcx - nd / 2, ty + BORDER / 2, nd, h - BORDER, nd, nd);
                    let nextZh = TextUtil.getCjkParts(stn), nextEn = TextUtil.getNonCjkParts(stn);
                    g.setColor(BLACK);
                    g.setFont(SERIF.deriveFont(0, 20)); RightTextXY(g, nextZh, pcx - WIDTH, cy - 5, Lm.leftName);
                    g.setFont(SANS.deriveFont(0, 10));  RightTextXY(g, nextEn, pcx - WIDTH, cy + 10, Lm.leftName);
                }
            }
            g.setColor(borderColor);
            let cx = pcx, kk = icsSize;
            let ty = LINEY - (kk * WIDTH + kk * INTERCHANGESPACING) - WIDTH / 2 - (RADIUS - WIDTH) / 2;
            let h = (kk + 1) * WIDTH + kk * INTERCHANGESPACING + (RADIUS - WIDTH);
            g.fillRoundRect(cx - RADIUS / 2, ty, RADIUS, h, RADIUS, RADIUS);
            let nd = RADIUS - BORDER;
            if (i < ns) { g.setColor(WHITE); } else if (i == ns) { g.setColor(NEXTCOLOR); } else { g.setColor(YELLOW); }
            g.fillRoundRect(cx - nd / 2, ty + BORDER / 2, nd, h - BORDER, nd, nd);
        }
    }
    let cx = pcx, cy = LINEY;
    if (jlen(rp.routeInterchanges) <= 1 || i < ns) {
        g.setColor(borderColor);
        g.fillRoundRect(cx - RADIUS / 2, cy - RADIUS / 2, RADIUS, RADIUS, RADIUS, RADIUS);
        if (i < ns) { g.setColor(WHITE); } else if (i == ns) { g.setColor(NEXTCOLOR); } else { g.setColor(YELLOW); }
        let nd = RADIUS - BORDER;
        g.fillRoundRect(cx - nd / 2, cy - nd / 2, nd, nd, nd, nd);
    }
    let next = rp.station.name, nextZh = TextUtil.getCjkParts(next), nextEn = TextUtil.getNonCjkParts(next);
    if (i < ns) { g.setColor(LIGHT_GREY); } else { g.setColor(BLACK); }
    if (icsSize > 0 && hasConics) {
        g.setFont(SERIF.deriveFont(0, 30)); LeftText(g, nextZh, cx + 15, cy + 50, Lm.nameL);
        g.setFont(SANS.deriveFont(0, 15));  LeftText(g, nextEn, cx + 15, cy + 68, Lm.nameL);
    } else {
        g.setFont(SERIF.deriveFont(0, 30)); CentreText(g, nextZh, cx, cy + 50, Lm.nameC);
        g.setFont(SANS.deriveFont(0, 15));  CentreText(g, nextEn, cx, cy + 68, Lm.nameC);
    }
}

// ===================== 入口：设备裁剪 + 统一 1.25 缩放 =====================
// texX = 该 slot 在整张纹理里的设备 x 起点（左墙 0，右墙 3000）。
// 流程：复位 → 平移到本半区(设备) → 裁剪 3000×500(设备) → 统一 scale(1.25) → 在虚拟 2400×400 里画。
// 这样旧绘制代码零改动，且字形等比放大、不变形；LINEY 投到设备 250 = 竖向正中。
function DrawInfoPanel(g, state, routePlats, nextStopIndex, hasArrived, doorClosing, comingNext, shouldLeft, texX) {
    let _bt = g.getTransform();
    let _bc = g.getClip();
    g.setTransform(new AffineTransform());
    g.setClip(null);
    if (texX == undefined || texX == null) { texX = 0; }
    g.translate(texX, 0);
    g.clipRect(0, 0, DEVICE_W, DEVICE_H);
    g.scale(SCALE, SCALE);

    if (routePlats != null && routePlats != undefined && jlen(routePlats) > 0 &&
        nextStopIndex >= 0 && nextStopIndex < jlen(routePlats) && jget(routePlats, nextStopIndex) != null) {
        if (!hasArrived) {
            if (comingNext && jlen(routePlats) > 5) {
                if (shouldLeft) { DrawComingNextLeft(g, state, routePlats, nextStopIndex); }
                else            { DrawComingNext(g, state, routePlats, nextStopIndex); }
            } else {
                if (shouldLeft) { DrawWholeMapLeft(g, state, routePlats, nextStopIndex); }
                else            { DrawWholeMap(g, state, routePlats, nextStopIndex); }
            }
        } else {
            DrawArrivalScreen(g, state, routePlats, nextStopIndex, doorClosing);
        }
    } else {
        g.setColor(WHITE); g.fillRect(0, 0, WIDTH1, HEIGHT1);
    }

    g.setTransform(_bt);
    g.setClip(_bc);
}

// ===================== 右向画面 =====================
function DrawWholeMap(g, state, routePlats, nextStopIndex) {
    let _t0 = g.getTransform();
    let NEXTCOLOR = (state.infoPanelCycle.stateNow() == "next") ? Color.decode("#ffffff") : Color.decode("#ffff00");
    let N = jlen(routePlats), idxList = [], i;
    for (i = 0; i < N; i++) { idxList.push(i); }
    let lay = layoutWhole(g, routePlats, idxList, nextStopIndex);
    let X = lay.X, lim = lay.lim;
    let routeColor = new Color(jget(routePlats, nextStopIndex).route.getColor());
    let routeName = jget(routePlats, nextStopIndex).route.getName();
    g.setColor(WHITE); g.fillRect(0, 0, WIDTH1, HEIGHT1);
    g.setColor(routeColor);
    g.fillRoundRect(LEGENDMARGIN / 4, LEGENDMARGIN * 0.35, WIDTH1 / 25, WIDTH / 2, WIDTH / 2, WIDTH / 2);
    let lecy = LEGENDMARGIN * 0.35 + WIDTH / 4, legX = LEGENDMARGIN / 4 + WIDTH1 / 25 + 10, legLim = WIDTH1 - legX - 10;
    g.setColor(BLACK);
    g.setFont(SERIF.deriveFont(0, 20)); LeftTextXY(g, TextUtil.getCjkParts(routeName), legX, lecy - 5, legLim);
    g.setFont(SANS.deriveFont(0, 10));  LeftTextXY(g, TextUtil.getNonCjkParts(routeName), legX, lecy + 10, legLim);
    let transformed = false;
    if (lay.transformed) { g.translate(lay.tx, lay.ty); g.scale(lay.s, lay.s); transformed = true; }
    drawBarWhole(g, X, idxList, nextStopIndex, routeColor);
    let borderColor = LIGHT_GREY;
    for (i = 0; i < N; i++) {
        if (borderColor == LIGHT_GREY && i >= nextStopIndex) { borderColor = BLACK; }
        let Lm = (lim && lim[i]) ? lim[i] : { rightLabel: 9999, leftName: 9999, single: 9999, nameC: 9999, nameL: 9999 };
        drawStation(g, X[i], Lm, jget(routePlats, i), i, nextStopIndex, borderColor, NEXTCOLOR);
    }
    let acx = (nextStopIndex >= 1) ? ((X[nextStopIndex - 1] + X[nextStopIndex]) / 2) : (X[0] - 30);
    let ah = WIDTH - 5, aw = ah * RATIO;
    g.drawImage(ARROW, acx - aw / 2, LINEY - ah / 2, aw, ah, null);
    if (transformed) { g.setTransform(_t0); }
}

function DrawComingNext(g, state, routePlats, nextStopIndex) {
    let _t0 = g.getTransform();
    let NEXTCOLOR = (state.infoPanelCycle.stateNow() == "next") ? Color.decode("#ffffff") : Color.decode("#ffff00");
    let N = jlen(routePlats), win = 5;
    let start = nextStopIndex - 2;
    if (start < 0) { start = 0; }
    if (start + win > N) { start = N - win; }
    if (start < 0) { start = 0; }
    let idxList = [], k;
    for (k = 0; k < win; k++) { idxList.push(start + k); }
    let lay = layoutComing(g, routePlats, idxList, nextStopIndex);
    let X = lay.X, lim = lay.lim;
    let routeColor = new Color(jget(routePlats, nextStopIndex).route.getColor());
    g.setColor(WHITE); g.fillRect(0, 0, WIDTH1, HEIGHT1);
    let transformed = false;
    if (lay.transformed) { g.translate(lay.tx, lay.ty); g.scale(lay.s, lay.s); transformed = true; }
    drawBarComing(g, X, idxList, nextStopIndex, routeColor, start, N);
    let borderColor = LIGHT_GREY;
    for (k = 0; k < win; k++) {
        let i = idxList[k];
        if (borderColor == LIGHT_GREY && i >= nextStopIndex) { borderColor = BLACK; }
        let Lm = (lim && lim[k]) ? lim[k] : { rightLabel: 9999, leftName: 9999, single: 9999, nameC: 9999, nameL: 9999 };
        drawStation(g, X[k], Lm, jget(routePlats, i), i, nextStopIndex, borderColor, NEXTCOLOR);
    }
    let lc = nextStopIndex - start;
    let acx = (lc >= 1 && lc < win) ? ((X[lc - 1] + X[lc]) / 2) : (X[0] - 30);
    let ah = WIDTH - 5, aw = ah * RATIO;
    g.drawImage(ARROW, acx - aw / 2, LINEY - ah / 2, aw, ah, null);
    if (transformed) { g.setTransform(_t0); }
}

// ===================== 左向画面（虚拟空间镜像 + 虚拟空间翻转箭头）=====================
function drawBarWholeLeft(g, X, idxList, ns, routeColor, MW) {
    for (let p = 0; p < idxList.length - 1; p++) {
        g.setColor(idxList[p] < ns - 1 ? LIGHT_GREY : routeColor);
        let x0 = X[p], x1 = X[p + 1];
        g.fillRect(MW - Math.max(x0, x1), LINEY - WIDTH / 2, Math.abs(x1 - x0), WIDTH);
    }
}
function drawBarComingLeft(g, X, idxList, ns, routeColor, start, N, MW) {
    let n = idxList.length;
    if (start != 0) { g.setColor(LIGHT_GREY); g.fillRect(MW - X[0], LINEY - WIDTH / 2, X[0], WIDTH); }
    for (let p = 0; p < n - 1; p++) {
        g.setColor(idxList[p] < ns - 1 ? LIGHT_GREY : routeColor);
        let x0 = X[p], x1 = X[p + 1];
        g.fillRect(MW - Math.max(x0, x1), LINEY - WIDTH / 2, Math.abs(x1 - x0), WIDTH);
    }
    if (start + n - 1 != N - 1) { g.setColor(routeColor); g.fillRect(MW - WIDTH1, LINEY - WIDTH / 2, WIDTH1 - X[n - 1], WIDTH); }
}
function drawStationLeft(g, pcx, Lm, rp, i, ns, borderColor, NEXTCOLOR, MW) {
    function RX(u) { return MW - u; }
    function LXedge(a, w) { return MW - a - w; }
    let icsSize = 0, hasConics = false;
    if (i >= ns || LAYOUT_COUNTS_PASSED_IC) {
        let ics = rp.routeInterchanges, conics = rp.connectingInterchanges;
        icsSize = jlen(ics);
        let conKeys = mapKeys(conics);
        hasConics = conKeys.length > 0;
        if (icsSize == 0 && hasConics) {
            let cony = LINEY, coniccy = {};
            for (let ki = 0; ki < conKeys.length; ki++) {
                let stn = conKeys[ki], conList = jmapget(conics, stn), conListSize = jlen(conList);
                g.setStroke(DOTTED); g.setColor(BLACK);
                g.drawLine(RX(pcx), cony, RX(pcx), cony - CONNECTINGINTERCHANGESPACING);
                cony = cony - CONNECTINGINTERCHANGESPACING;
                coniccy[stn] = cony - (conListSize * WIDTH + (conListSize - 1) * INTERCHANGESPACING) / 2;
                for (let ci = 0; ci < conListSize; ci++) {
                    let ic = jget(conList, ci), iccol = new Color(ic.color);
                    let icZh = TextUtil.getCjkParts(ic.name), icEn = TextUtil.getNonCjkParts(ic.name);
                    let iw = WIDTH, ilx = pcx, icy = cony - WIDTH / 2;
                    g.setColor(iccol);
                    g.fillRect(LXedge(ilx, iw * 1.25), icy - iw / 2, iw * 1.25, iw);
                    g.fillOval(LXedge(ilx + iw * 1.25 / 2, iw), icy - iw / 2, iw, iw);
                    g.setColor(BLACK);
                    g.setFont(SERIF.deriveFont(0, 20)); RightTextXY(g, icZh, RX(ilx + iw * 1.7), icy - 5, Lm.rightLabel);
                    g.setFont(SANS.deriveFont(0, 10));  RightTextXY(g, icEn, RX(ilx + iw * 1.7), icy + 10, Lm.rightLabel);
                    cony = cony - WIDTH - INTERCHANGESPACING;
                }
                cony = cony + WIDTH + INTERCHANGESPACING;
            }
            for (let ki = 0; ki < conKeys.length; ki++) {
                let stn = conKeys[ki], stnics = jmapget(conics, stn), kk = jlen(stnics), cy = coniccy[stn];
                let h = kk * WIDTH + (kk - 1) * INTERCHANGESPACING + (RADIUS - WIDTH), ty = cy - h / 2;
                g.setColor(borderColor); g.fillRoundRect(LXedge(pcx - RADIUS / 2, RADIUS), ty, RADIUS, h, RADIUS, RADIUS);
                let nd = RADIUS - BORDER; g.setColor(WHITE); g.fillRoundRect(LXedge(pcx - nd / 2, nd), ty + BORDER / 2, nd, h - BORDER, nd, nd);
                let nextZh = TextUtil.getCjkParts(stn), nextEn = TextUtil.getNonCjkParts(stn);
                g.setColor(BLACK);
                g.setFont(SERIF.deriveFont(0, 20)); LeftTextXY(g, nextZh, RX(pcx - WIDTH), cy - 5, Lm.leftName);
                g.setFont(SANS.deriveFont(0, 10));  LeftTextXY(g, nextEn, RX(pcx - WIDTH), cy + 10, Lm.leftName);
            }
        } else if (icsSize == 1) {
            let iic = jget(ics, 0), iiccol = new Color(iic.color);
            let iicZh = TextUtil.getCjkParts(iic.name), iicEn = TextUtil.getNonCjkParts(iic.name);
            let iiw = WIDTH, iicx = pcx, iirty = LINEY - iiw * 1.25, iity = iirty - iiw / 2;
            g.setColor(iiccol);
            g.fillRect(LXedge(iicx - iiw / 2, iiw), iirty, iiw, iiw);
            g.fillOval(LXedge(iicx - iiw / 2, iiw), iity, iiw, iiw);
            g.setColor(BLACK);
            g.setFont(SERIF.deriveFont(0, 20)); CentreText(g, iicZh, RX(iicx), iity - 20, Lm.single);
            g.setFont(SANS.deriveFont(0, 10));  CentreText(g, iicEn, RX(iicx), iity - 5, Lm.single);
            if (hasConics) {
                let cony = LINEY, coniccy = {};
                for (let ki = 0; ki < conKeys.length; ki++) {
                    let stn = conKeys[ki], conList = jmapget(conics, stn), conListSize = jlen(conList);
                    g.setStroke(DOTTED); g.setColor(BLACK);
                    g.drawLine(RX(pcx), cony, RX(pcx), cony + CONNECTINGINTERCHANGESPACING);
                    cony = cony + CONNECTINGINTERCHANGESPACING;
                    coniccy[stn] = cony + (conListSize * WIDTH + (conListSize - 1) * INTERCHANGESPACING) / 2;
                    for (let ci = 0; ci < conListSize; ci++) {
                        let ic = jget(conList, ci), iccol = new Color(ic.color);
                        let icZh = TextUtil.getCjkParts(ic.name), icEn = TextUtil.getNonCjkParts(ic.name);
                        let iw = WIDTH, ilx = pcx, icy = cony + WIDTH / 2;
                        g.setColor(iccol);
                        g.fillRect(LXedge(ilx, iw * 1.25), icy - iw / 2, iw * 1.25, iw);
                        g.fillOval(LXedge(ilx + iw * 1.25 / 2, iw), icy - iw / 2, iw, iw);
                        g.setColor(BLACK);
                        g.setFont(SERIF.deriveFont(0, 20)); RightTextXY(g, icZh, RX(ilx + iw * 1.7), icy - 5, Lm.rightLabel);
                        g.setFont(SANS.deriveFont(0, 10));  RightTextXY(g, icEn, RX(ilx + iw * 1.7), icy + 10, Lm.rightLabel);
                        cony = cony + WIDTH + INTERCHANGESPACING;
                    }
                    cony = cony - WIDTH - INTERCHANGESPACING;
                }
                for (let ki = 0; ki < conKeys.length; ki++) {
                    let stn = conKeys[ki], stnics = jmapget(conics, stn), kk = jlen(stnics), cy = coniccy[stn];
                    let h = kk * WIDTH + (kk - 1) * INTERCHANGESPACING + (RADIUS - WIDTH), ty = cy - h / 2;
                    g.setColor(borderColor); g.fillRoundRect(LXedge(pcx - RADIUS / 2, RADIUS), ty, RADIUS, h, RADIUS, RADIUS);
                    let nd = RADIUS - BORDER; g.setColor(WHITE); g.fillRoundRect(LXedge(pcx - nd / 2, nd), ty + BORDER / 2, nd, h - BORDER, nd, nd);
                    let nextZh = TextUtil.getCjkParts(stn), nextEn = TextUtil.getNonCjkParts(stn);
                    g.setColor(BLACK);
                    g.setFont(SERIF.deriveFont(0, 20)); LeftTextXY(g, nextZh, RX(pcx - WIDTH), cy - 5, Lm.leftName);
                    g.setFont(SANS.deriveFont(0, 10));  LeftTextXY(g, nextEn, RX(pcx - WIDTH), cy + 10, Lm.leftName);
                }
            }
        } else if (icsSize > 1) {
            for (let j = 0; j < icsSize; j++) {
                let ic = jget(ics, j);
                if (ic != undefined) {
                    let iccol = new Color(ic.color);
                    let icZh = TextUtil.getCjkParts(ic.name), icEn = TextUtil.getNonCjkParts(ic.name);
                    let iw = WIDTH, ilx = pcx, icy = LINEY - ((j + 1) * WIDTH + (j + 1) * INTERCHANGESPACING);
                    g.setColor(iccol);
                    g.fillRect(LXedge(ilx, iw * 1.25), icy - iw / 2, iw * 1.25, iw);
                    g.fillOval(LXedge(ilx + iw * 1.25 / 2, iw), icy - iw / 2, iw, iw);
                    g.setColor(BLACK);
                    g.setFont(SERIF.deriveFont(0, 20)); RightTextXY(g, icZh, RX(ilx + iw * 1.7), icy - 5, Lm.rightLabel);
                    g.setFont(SANS.deriveFont(0, 10));  RightTextXY(g, icEn, RX(ilx + iw * 1.7), icy + 10, Lm.rightLabel);
                }
            }
            if (hasConics) {
                let cony = LINEY, coniccy = {};
                for (let ki = 0; ki < conKeys.length; ki++) {
                    let stn = conKeys[ki], conList = jmapget(conics, stn), conListSize = jlen(conList);
                    g.setStroke(DOTTED); g.setColor(BLACK);
                    g.drawLine(RX(pcx), cony, RX(pcx), cony + CONNECTINGINTERCHANGESPACING);
                    cony = cony + CONNECTINGINTERCHANGESPACING;
                    coniccy[stn] = cony + (conListSize * WIDTH + (conListSize - 1) * INTERCHANGESPACING) / 2;
                    for (let ci = 0; ci < conListSize; ci++) {
                        let ic = jget(conList, ci), iccol = new Color(ic.color);
                        let icZh = TextUtil.getCjkParts(ic.name), icEn = TextUtil.getNonCjkParts(ic.name);
                        let iw = WIDTH, ilx = pcx, icy = cony + WIDTH / 2;
                        g.setColor(iccol);
                        g.fillRect(LXedge(ilx, iw * 1.25), icy - iw / 2, iw * 1.25, iw);
                        g.fillOval(LXedge(ilx + iw * 1.25 / 2, iw), icy - iw / 2, iw, iw);
                        g.setColor(BLACK);
                        g.setFont(SERIF.deriveFont(0, 20)); RightTextXY(g, icZh, RX(ilx + iw * 1.7), icy - 5, Lm.rightLabel);
                        g.setFont(SANS.deriveFont(0, 10));  RightTextXY(g, icEn, RX(ilx + iw * 1.7), icy + 10, Lm.rightLabel);
                        cony = cony + WIDTH + INTERCHANGESPACING;
                    }
                    cony = cony - WIDTH - INTERCHANGESPACING;
                }
                for (let ki = 0; ki < conKeys.length; ki++) {
                    let stn = conKeys[ki], stnics = jmapget(conics, stn), kk = jlen(stnics), cy = coniccy[stn];
                    let h = kk * WIDTH + (kk - 1) * INTERCHANGESPACING + (RADIUS - WIDTH), ty = cy - h / 2;
                    g.setColor(borderColor); g.fillRoundRect(LXedge(pcx - RADIUS / 2, RADIUS), ty, RADIUS, h, RADIUS, RADIUS);
                    let nd = RADIUS - BORDER; g.setColor(WHITE); g.fillRoundRect(LXedge(pcx - nd / 2, nd), ty + BORDER / 2, nd, h - BORDER, nd, nd);
                    let nextZh = TextUtil.getCjkParts(stn), nextEn = TextUtil.getNonCjkParts(stn);
                    g.setColor(BLACK);
                    g.setFont(SERIF.deriveFont(0, 20)); LeftTextXY(g, nextZh, RX(pcx - WIDTH), cy - 5, Lm.leftName);
                    g.setFont(SANS.deriveFont(0, 10));  LeftTextXY(g, nextEn, RX(pcx - WIDTH), cy + 10, Lm.leftName);
                }
            }
            g.setColor(borderColor);
            let cx = pcx, kk = icsSize;
            let ty = LINEY - (kk * WIDTH + kk * INTERCHANGESPACING) - WIDTH / 2 - (RADIUS - WIDTH) / 2;
            let h = (kk + 1) * WIDTH + kk * INTERCHANGESPACING + (RADIUS - WIDTH);
            g.fillRoundRect(LXedge(cx - RADIUS / 2, RADIUS), ty, RADIUS, h, RADIUS, RADIUS);
            let nd = RADIUS - BORDER;
            if (i < ns) { g.setColor(WHITE); } else if (i == ns) { g.setColor(NEXTCOLOR); } else { g.setColor(YELLOW); }
            g.fillRoundRect(LXedge(cx - nd / 2, nd), ty + BORDER / 2, nd, h - BORDER, nd, nd);
        }
    }
    let cx = pcx, cy = LINEY;
    if (jlen(rp.routeInterchanges) <= 1 || (i < ns && !LAYOUT_COUNTS_PASSED_IC)) {
        g.setColor(borderColor);
        g.fillRoundRect(LXedge(cx - RADIUS / 2, RADIUS), cy - RADIUS / 2, RADIUS, RADIUS, RADIUS, RADIUS);
        if (i < ns) { g.setColor(WHITE); } else if (i == ns) { g.setColor(NEXTCOLOR); } else { g.setColor(YELLOW); }
        let nd = RADIUS - BORDER;
        g.fillRoundRect(LXedge(cx - nd / 2, nd), cy - nd / 2, nd, nd, nd, nd);
    }
    let next = rp.station.name, nextZh = TextUtil.getCjkParts(next), nextEn = TextUtil.getNonCjkParts(next);
    if (i < ns) { g.setColor(LIGHT_GREY); } else { g.setColor(BLACK); }
    if (icsSize > 0 && hasConics) {
        g.setFont(SERIF.deriveFont(0, 30)); RightText(g, nextZh, RX(cx + 15), cy + 50, Lm.nameL);
        g.setFont(SANS.deriveFont(0, 15));  RightText(g, nextEn, RX(cx + 15), cy + 68, Lm.nameL);
    } else {
        g.setFont(SERIF.deriveFont(0, 30)); CentreText(g, nextZh, RX(cx), cy + 50, Lm.nameC);
        g.setFont(SANS.deriveFont(0, 15));  CentreText(g, nextEn, RX(cx), cy + 68, Lm.nameC);
    }
}

function DrawWholeMapLeft(g, state, routePlats, nextStopIndex) {
    let _t0 = g.getTransform();
    let NEXTCOLOR = (state.infoPanelCycle.stateNow() == "next") ? Color.decode("#ffffff") : Color.decode("#ffff00");
    let N = jlen(routePlats), idxList = [], i;
    for (i = 0; i < N; i++) { idxList.push(i); }
    let lay = layoutWhole(g, routePlats, idxList, nextStopIndex);
    let X = lay.X, lim = lay.lim;
    let routeColor = new Color(jget(routePlats, nextStopIndex).route.getColor());
    let routeName = jget(routePlats, nextStopIndex).route.getName();
    let MW = lay.transformed ? ((WIDTH1 - 2 * lay.tx) / lay.s) : WIDTH1;
    g.setColor(WHITE); g.fillRect(0, 0, WIDTH1, HEIGHT1);
    g.setColor(routeColor);
    g.fillRoundRect(WIDTH1 - LEGENDMARGIN / 4 - WIDTH1 / 25, LEGENDMARGIN * 0.35, WIDTH1 / 25, WIDTH / 2, WIDTH / 2, WIDTH / 2);
    let lecy = LEGENDMARGIN * 0.35 + WIDTH / 4, legX = LEGENDMARGIN / 4 + WIDTH1 / 25 + 10, legLim = WIDTH1 - legX - 10;
    g.setColor(BLACK);
    g.setFont(SERIF.deriveFont(0, 20)); RightTextXY(g, TextUtil.getCjkParts(routeName), WIDTH1 - legX, lecy - 5, legLim);
    g.setFont(SANS.deriveFont(0, 10));  RightTextXY(g, TextUtil.getNonCjkParts(routeName), WIDTH1 - legX, lecy + 10, legLim);
    let transformed = false;
    if (lay.transformed) { g.translate(lay.tx, lay.ty); g.scale(lay.s, lay.s); transformed = true; }
    drawBarWholeLeft(g, X, idxList, nextStopIndex, routeColor, MW);
    let borderColor = LIGHT_GREY;
    for (i = 0; i < N; i++) {
        if (borderColor == LIGHT_GREY && i >= nextStopIndex) { borderColor = BLACK; }
        let Lm = (lim && lim[i]) ? lim[i] : { rightLabel: 9999, leftName: 9999, single: 9999, nameC: 9999, nameL: 9999 };
        drawStationLeft(g, X[i], Lm, jget(routePlats, i), i, nextStopIndex, borderColor, NEXTCOLOR, MW);
    }
    // 箭头：在虚拟空间关于“镜像中点”水平翻转（不再复位到设备 identity，避免双墙串色）
    let acx = (nextStopIndex >= 1) ? ((X[nextStopIndex - 1] + X[nextStopIndex]) / 2) : (X[0] - 30);
    let ah = WIDTH - 5, aw = ah * RATIO;
    let acxM = MW - acx;
    let tSave = g.getTransform();
    g.translate(acxM, LINEY);
    g.scale(-1, 1);
    g.drawImage(ARROW, -aw / 2, -ah / 2, aw, ah, null);
    g.setTransform(tSave);
    if (transformed) { g.setTransform(_t0); }
}

function DrawComingNextLeft(g, state, routePlats, nextStopIndex) {
    let _t0 = g.getTransform();
    let NEXTCOLOR = (state.infoPanelCycle.stateNow() == "next") ? Color.decode("#ffffff") : Color.decode("#ffff00");
    let N = jlen(routePlats), win = 5;
    let start = nextStopIndex - 2;
    if (start < 0) { start = 0; }
    if (start + win > N) { start = N - win; }
    if (start < 0) { start = 0; }
    let idxList = [], k;
    for (k = 0; k < win; k++) { idxList.push(start + k); }
    let lay = layoutComing(g, routePlats, idxList, nextStopIndex);
    let X = lay.X, lim = lay.lim;
    let routeColor = new Color(jget(routePlats, nextStopIndex).route.getColor());
    let MW = lay.transformed ? ((WIDTH1 - 2 * lay.tx) / lay.s) : WIDTH1;
    g.setColor(WHITE); g.fillRect(0, 0, WIDTH1, HEIGHT1);
    let transformed = false;
    if (lay.transformed) { g.translate(lay.tx, lay.ty); g.scale(lay.s, lay.s); transformed = true; }
    drawBarComingLeft(g, X, idxList, nextStopIndex, routeColor, start, N, MW);
    let borderColor = LIGHT_GREY;
    for (k = 0; k < win; k++) {
        let i = idxList[k];
        if (borderColor == LIGHT_GREY && i >= nextStopIndex) { borderColor = BLACK; }
        let Lm = (lim && lim[k]) ? lim[k] : { rightLabel: 9999, leftName: 9999, single: 9999, nameC: 9999, nameL: 9999 };
        drawStationLeft(g, X[k], Lm, jget(routePlats, i), i, nextStopIndex, borderColor, NEXTCOLOR, MW);
    }
    let lc = nextStopIndex - start;
    let acx = (lc >= 1 && lc < win) ? ((X[lc - 1] + X[lc]) / 2) : (X[0] - 30);
    let ah = WIDTH - 5, aw = ah * RATIO;
    let acxM = MW - acx;
    let tSave = g.getTransform();
    g.translate(acxM, LINEY);
    g.scale(-1, 1);
    g.drawImage(ARROW, -aw / 2, -ah / 2, aw, ah, null);
    g.setTransform(tSave);
    if (transformed) { g.setTransform(_t0); }
}

// ===================== 到站屏 =====================
function DrawArrivalScreen(g, state, routePlats, nextStopIndex, doorClosing) {
    let NEXTCOLOR = (state.infoPanelCycle.stateNow() == "next") ? Color.decode("#ffffff") : Color.decode("#ffff00");
    g.setColor(WHITE); g.fillRect(0, 0, WIDTH1, HEIGHT1);
    let cx = WIDTH1 / 2, cy = (HEIGHT1 - ARRIVALYELLOWPARTHEIGHT) / 2;
    g.setColor(BLACK);
    g.fillRoundRect(cx - ARRIVALRADIUS / 2, cy - ARRIVALRADIUS / 2, ARRIVALRADIUS, ARRIVALRADIUS, ARRIVALRADIUS, ARRIVALRADIUS);
    g.setColor(NEXTCOLOR);
    let nd = ARRIVALRADIUS - ARRIVALBORDER;
    g.fillRoundRect(cx - nd / 2, cy - nd / 2, nd, nd, nd, nd);
    let next = jget(routePlats, nextStopIndex).station.name;
    g.setColor(BLACK);
    g.setFont(SERIF.deriveFont(0, ARRIVALRADIUS * 0.8)); RightTextXY(g, TextUtil.getCjkParts(next), cx - ARRIVALRADIUS * 0.75, cy, cx - ARRIVALRADIUS * 2);
    g.setFont(SANS.deriveFont(0, ARRIVALRADIUS * 0.8));  LeftTextXY(g, TextUtil.getNonCjkParts(next), cx + ARRIVALRADIUS * 0.75, cy, cx - ARRIVALRADIUS * 2);
    g.setColor(YELLOW);
    g.fillRect(0, HEIGHT1 - ARRIVALYELLOWPARTHEIGHT, WIDTH1, ARRIVALYELLOWPARTHEIGHT);
    let yellowZh = "请小心月台空隙", yellowEn = "Please mind the gap";
    let yty = HEIGHT1 - ARRIVALYELLOWPARTHEIGHT / 2;
    let mtgmargin = 60, mtgsize = 100;
    if (doorClosing) {
        yellowZh = "请勿靠近车门"; yellowEn = "Please stand back from the doors";
    } else {
        if (MTGL) { g.drawImage(MTGL, mtgmargin, yty - mtgsize / 2, mtgsize, mtgsize, null); }
        if (MTGR) { g.drawImage(MTGR, WIDTH1 - mtgsize - mtgmargin, yty - mtgsize / 2, mtgsize, mtgsize, null); }
    }
    g.setColor(BLACK);
    g.setFont(SERIF.deriveFont(0, ARRIVALYELLOWPARTHEIGHT - 30)); RightTextXY(g, yellowZh, cx - 7.5, yty, WIDTH1 / 2 - mtgmargin - mtgsize - 10);
    g.setFont(SANS.deriveFont(0, ARRIVALYELLOWPARTHEIGHT - 30));  LeftTextXY(g, yellowEn, cx + 7.5, yty, WIDTH1 / 2 - mtgmargin - mtgsize - 10);
}