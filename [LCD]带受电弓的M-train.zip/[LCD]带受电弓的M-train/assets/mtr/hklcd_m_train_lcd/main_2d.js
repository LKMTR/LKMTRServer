// MTR模组M-Train资趣台 v1.7 —— 每墙 3000×500，整张纹理 6000×500
// 2026年-当前 仙芳佳全域通达铁路、乐文彩雨 版权所有  MIT
// 作者b站：https://space.bilibili.com/104383166
include(Resources.id("mtrsteamloco:scripts/display_helper.js"));
include("formatting.js");
include("info-panel.js");

var infoPanelConfig = JSON.parse(Resources.readString(Resources.id("mtr:hklcd_m_train_lcd/slots_2d.json")));

//const leftPos = getCubeVertices([0.846,2.072,0.688], [0.658,2.072,-0.688],[0.752,2.072,0],0,-180,-50);
//const rightPos = getCubeVertices([-0.846,2.072,-0.688],[-0.658,2.072,0.688], [-0.752,2.072,0],0,180,50);
var infoPanelGenerator = new DisplayHelper(infoPanelConfig);

function create(ctx, state, train) {
    ctx.setDataFetchMode("ALL");
    state.refreshRate = new RateLimit(0.1);
    state.infoPanelCycle = new CycleTracker(["next", 1, "notice", 1]);
    state.infoPanel = infoPanelGenerator.create();
}

function render(ctx, state, train) {
    ctx.setDataFetchMode("ALL");
    if (state.infoPanel == undefined || state.infoPanel == null) {
        state.infoPanel = infoPanelGenerator.create();
        state.refreshRate = new RateLimit(0.1);
        state.infoPanelCycle = new CycleTracker(["next", 1, "notice", 1]);
    }
    if (state.refreshRate.shouldUpdate()) {
        state.infoPanelCycle.tick();
        let routePlats = train.getThisRoutePlatforms();
        let nextStopIndex = 0;
        let distancePassed = 0;
        let distanceOfPlatFromStart = 0;
        if (train.getThisRoutePlatformsNextIndex() != undefined && train.getThisRoutePlatformsNextIndex() != null) {
            nextStopIndex = train.getThisRoutePlatformsNextIndex();
        }
        if (train.railProgress() != undefined && train.railProgress() != null) {
            distancePassed = train.railProgress();
        }
        let hasArrived = false, doorClosing = false, comingNext = false;
        if (routePlats != undefined && routePlats != null && nextStopIndex < routePlats.size()) {
            distanceOfPlatFromStart = routePlats.get(nextStopIndex).distance;
            hasArrived = (distancePassed >= distanceOfPlatFromStart - 0.5 && distancePassed <= distanceOfPlatFromStart);
            let prevDist = (nextStopIndex > 0) ? routePlats.get(nextStopIndex - 1).distance : 0;
            let legLength = distanceOfPlatFromStart - prevDist;
            let travelledInLeg = distancePassed - prevDist;
            let quarter = legLength / 4;
            let threshold = (quarter <= 250) ? quarter : 250;
            comingNext = (travelledInLeg <= threshold);
        }
        doorClosing = (train.getElapsedDwellTime() >= train.getTotalDwellTime() / 2 && train.getDoorValue() < 1.0);

        let isReversed = train.isReversed();
        // 第 9 个参数 = 该 slot 的设备 x 起点（左 0 / 右 3000），必须与 texArea 的 x 一致
        let g = state.infoPanel.graphicsFor("lcd_door_left");
        DrawInfoPanel(g, state, routePlats, nextStopIndex, hasArrived, doorClosing, comingNext, isReversed, 0);
        g = state.infoPanel.graphicsFor("lcd_door_right");
        DrawInfoPanel(g, state, routePlats, nextStopIndex, hasArrived, doorClosing, comingNext, !isReversed, 3000);

        state.infoPanel.upload();
    }
    for (let i = 0; i < train.trainCars(); i++) {
        ctx.drawCarModel(state.infoPanel.model, i, null);
    }
}

function dispose(ctx, state, train) { state.infoPanel.close(); }